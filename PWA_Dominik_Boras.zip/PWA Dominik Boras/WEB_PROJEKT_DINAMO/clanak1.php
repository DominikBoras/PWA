<html>
        <link rel="stylesheet" href="style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datum"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="momcad.php">Momčad</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
            <h2>Aktualne vijesti</h2>
        </div>

        <div class="naslovClanka">
            <h4>ADEMI POTVRDIO DINAMOV 35. NASLOV PRVAKA</h4>
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika"><img src="clanak1.jpg"></div>
            <div class="sekcijaClanak">Aktualne vijesti</div>
            <div class="tekstClanak">
                <p>Plavetnilo maksimirskih tribina, slavlje Dinamu u čast, u slavu prvaku, navijačka oda plavim junacima... Dugo se razlijevala jeka kibica purgerskoga kluba, slavljenički zvon odzvanjao je Zagrebom jer Dinamo je ove subotnje večeri osigurao svoj 35. naslov prvaka u povijesti od čega 25. u Prvoj HNL. Štoviše, to je ujedno sedmi uzastopni naslov, a 18. u zadnjih 19 sezona! Trener Sergej Jakirović vodio je, dakle, do pobjede protiv Osijeka s 1:0 u dvoboju 34. kola Super Sport HNL-a čime je njegova momčad, dva kola prije kraja, pobjegla prvom pratitelju, Rijeci, na nedostižnih sedam bodova prednosti.</p>
                <p>I puno je simbolike u slavljeničkom potpisu ove subote: pobjedonosni pogodak parafirao je Dinamov maestro, redatelj, vođa i kapetan Arijan Ademi. Lucidnim je potezom zavukao loptu u mrežu u 72. minuti. A prostremo li brojke, statistiku pa i dojam, jasno je da Ademi, kao i kompletan plavi ansambl, zaslužuje duboki naklon: ovo je njegov rekordni 23. trofej u maksimirskom klubu pri čemu je baš u svakoj svojoj sezoni osvojio naslov prvaka!
                Josip Mišić u toj je, 72. minuti, ubacio desnom nogom s lijeva, a na drugoj vratnici Ademi se ušuljao kroz obranu i glavom zakucao za pobjedu i erupciju s tribina.</p>
                <p>Osijek je od 63. minute igrao s desetoricom nakon što je isključen stoper Andre Duarte. Prethodno se Arbër Hoxha sjurio prema vratima, a nadomak kaznenog prostora srušio ga je Duarte koji je, nakon pregleda VAR-a, dobio i crveni karton jer je maksimirski krilni napadač pritom imao otvoren put prema vratima.</p>
                <p>Gromoglasna je i emotivna bila i sama uvertira u utakmicu, neposredno uoči početka dvoboja na travnjak su izašli predstavnici generacije iz sezone 1989/'90. kao dio obilježavanja skorašnje 34. godišnjice zbivanja uoči nikad odigrane utakmice Dinama i Crvene zvezde iz 13. svibnja 1990., zbivanja koja mnogi, zbog konteksta vremena i društvenih okolnosti, simbolički smatraju početkom borbe za hrvatsku samostalnost i neovisnost.</p>
                <p>Na maksimirski su travnjak, uoči dvoboja protiv Osječana, iskoračili predstavnici tadašnje Dinamove generacije, bilo da su u momčadi bili u tom trenutku ili ranije u sezoni, i pritom ih je pozdravio aktualni predsjednik kluba, a tadašnji tehnički direktor, Velimir Zajec.</p>
                <p>Predvodio ih je kapetan Zvonimir Boban, a bili su tu i Mladen Mladenović, Muhamed Preljević, Kujtim Shala, Dražen Besek, Slavko Ištvanić, Vjekoslav Škrinjar, Dražen Boban, Fabijan Komljenović, Davor Matić i rezervni vratar Zdenko Miletić. Sve je, dakako, popraćeno i gromkim pljeskom koji se, eto, razlijegao i nakon same utakmice.</p>
                <p>Ipak, prvi je zaprijetio Osijek kad je Ramon Mierez u 7. minuti gađao oštrim trzajem glavom s desetak metara, a vratar Ivan Nevistić iščupao loptu ispod grede. Ubrzo je potom Stefan Ristovski ubacio s desna, Gabriel Vidović pokušao glavom, ali lopta je prohujala malo pored osječkih vrata. Dopadljiva je bila akcija plavih u tri poteza u 23. minuti, Martin Baturina odigrao je za Brunu Petkovića, a u nastavku Fran Brodić s 18 metara lansirao preko gola.
                <p>U smiraju prvog dijela Domagoj Bukvić na unutarnjem je rubu šesnaesterca s leđa zahvatio Petkovića po peti, a nakon pregleda VAR-a sudac je ipak procijenio da nije riječ o prekršaju za kazneni udarac. U sučevoj nadoknadi prvog dijela Petković je oštro gađao glavom nakon kornera, a lopta proletjela uza samu vratnicu.</p>
                <p>Na otvaranju drugog dijela pokušao je Petar Pušić s 20-ak metara, ali Nevistić je uspio skrenuti loptu. Odmah je potom zaiskrilo na drugoj strani kad je Baturina potegnuo s desna s ruba kaznenog prostora uza sami suprotni donji kut.</p>
                <p>Baturina je pljesak izmamio i u 85. minuti kad je vješto gađao škaricama s ruba kaznenog prostora, ali uza sami donji kut.</p>
                <p>Zagreb, 11. svibnja 2024.</p>
                <p>SuperSport HNL, 34. kolo</p>
                <p>Dinamo - Osijek 1:0</p>
                <p>Stadion Maksimir</p>
                <p>Dinamo: Nevistić - Ristovski, Theophile, Bernauer - Kaneko (71. Špikić), Ademi (83. Sučić), Mišić, Baturina (86. Rog), Vidović (46. Hoxha) - Brodić <p>(46. Ogiwara), Petković</p>
                <p>Trener: Sergej Jakirović</p>
                <p>Osijek: Kolić - Prekodravac, Duarte, Jurišić - Guedes, Çokaj (79. Jugović), Nejašmić (87. Fućak), Bukvić (64. Mkrtchyan); Pušić (79. Lovrić) - <p>Matković (79. Gržan), Mierez</p>
                <p>Trener: Zoran Zekić</p>
                <p>Sudac: Patrik Kolarić (Čakovec), Gledatelja: 18.126</p>
                <p>Crveni karton: Duarte (Osijek, 63. - prekršaj)</p>
                <p>Strijelci: 1:0 Ademi (72.)</p>
            </div>


        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>