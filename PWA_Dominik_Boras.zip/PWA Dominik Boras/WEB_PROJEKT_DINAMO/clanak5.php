<html>
        <link rel="stylesheet" href="style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datum"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="momcad.php">Momčad</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
            <h2>Informacije</h2>
        </div>

        <div class="naslovClanka">
            <h4>ULAZNICE ZA UTAKMICU DINAMO - OSIJEK NA STADIONU MAKSIMIR</h4>
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika"><img src="clanak5.jpg"></div>
            <div class="sekcijaClanak">Informacije</div>
            <div class="tekstClanak">
                
                <p>U subotu 11. svibnja 2024. Dinamo će na stadionu Maksimir odigrati susret 34. kola SuperSport HNL-a protiv Osijeka. Utakmica je na rasporedu u 19:30h.</p>
                <p>Cijene ulaznica za utakmicu Dinamo - Osijek: <br> Tribina zapad dolje - 15€ <br> Tribina sjever dolje - 5€ <br>Tribina sjever gore - 5€</p>
                <p>Ulaznice za tribinu Jug (5 eura) biti će u prodaji isključivo za gostujuće navijače, a prodaja će se vršiti na dan utakmice na blagajnama Borongaj od 17:00 do 20:15 sati.</p>
                <p>ONLINE prodaja ulaznica počinje u utorak, 07. svibnja u 11 sati i završava u subotu 11. svibnja u 19:30 sati.</p>
                <p>Fizička prodaja ulaznica na TICKET POINTU počinje u četvrtak, 09. svibnja u 11 sati.</p>
                <p>Prodaja na Ticket pointu: <br> Četvrtak 09.05. od 11 do 19 sati <br> Petak 10.05. od 11 do 19 sati <br> Subota 11.05 od 11 do 20:15 sati</p>
                <p>Godišnja ulaznica vrijedi za sve utakmice na stadionu Maksimir u natjecanjima Prva HNL, Hrvatski nogometni kup, Hrvatski superkup te za sve domaće utakmice UEFA natjecanja od srpnja 2023. do lipnja 2024.</p>
                <p>Napomena</p>
                <p>Preduvjet za kupovinu ulaznica za sve će navijače biti predočenje važećeg osobnog dokumenta (osobna iskaznica ili putovnica, za dijete rodni list, zdravstvena iskaznica ili putovnica), a sve su ulaznice i paketi personalizirani i glase na ime i prezime. Prilikom kupovine potrebno je prikazati osobni dokument za sve ulaznice. Napominjemo da GNK Dinamo neće prodavati ulaznice osobama kojima kupovinu priječi Zakon o sprječavanju nereda na sportskim natjecanjima.</p>
                <p>ČLANOVI - POGODNOST BESPLATNE ULAZNICE</p>
                <p>Članovi Dinama mogu iskoristiti pogodnost besplatnog ulaza na 4 utakmice Hrvatske nogometne lige i Hrvatskog kupa po vlastitom izboru do kraja kalendarske godine. Pogodnost za ovu utakmicu vrijedi za tribine zapad gore i sjever gore. Članovi besplatnu ulaznicu mogu preuzeti na ticket pointu uz predočenje članske iskaznice i osobne iskaznice u vremenu kada je ticket point otvoren za prodaju ulaznica ili online putem već od 07. svibnja.</p>
                <p>OTVARANJE STADIONA GNK Dinamo - NK Osijek</p>
                <p>Ulazi stadiona Maksimir bit će na dan utakmice Dinamo - Osijek otvoreni od 18:30 sati. Na ulazima na stadion Maksimir bit će organizirana kontrola dokumenta koji su uvjet za ulazak: <br> 1. Važeći osobni dokument <br> 2. Personalizirana ulaznica</p>
            </div> 
        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>