<html>
    <link rel="stylesheet" href="Style.css">    
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>

        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>

    <div class="bodyPage">

        <div class="section">
            <div class="naslovSekcije">
                <h2>O klubu</h2>
            </div>
            <div class="tekstClanak">
                <p>Građanski nogometni klub Dinamo Zagreb je hrvatski nogometni klub iz Zagreba. 
                <p>Od osnutka Republike Hrvatske najtrofejniji je klub u državi. Nadimci kluba su modri, zagrebački plavi, plavi lavovi,    purgeri.</p>
                <p>Maskota kluba je lav Plavko.</p>     
                <p>Domaće utakmice igra na Stadionu Maksimir. Dinamo je poznat po svojim vjernim i fanatičnim navijačima Bad Blue Boysima. Klub je cijenjen u svijetu po svojoj nogometnoj školi koja se zadnjih godina smatra za jednu od najboljih u Europi.</p>
                <div class="slikaTekst"><img src="dinamo.png" alt=""></div>
            </div>
            
        </div>  

        <hr>

        <div class="section">
            <div class="naslovSekcije">
                <h2>Povijest</h2>
            </div>
            <div class="tekstClanak">
                <p>Klub nastavlja tradiciju Prvog hrvatskog građanskog športskog kluba (Građanski) utemeljenog u travnju 1911. godine. Tijekom 34 godine djelovanja šest puta je osvojio naslov prvaka Kraljevine Jugoslavije i NDH (1923., 1926., 1928., 1937., 1940. i 1943.). Pod tim nazivom nastupao je do svibnja 1945. godine, a potom je rasformiran odlukom nove komunističke vlasti, a sva bogata pismohrana je vandalski uništena. Umjesto Građanskog utemeljeno je tada Fiskulturno društvo Dinamo, a pet godina kasnije osamostaljuje se njegov nogometni klub. Dinamo je od Građanskog baštinio veći dio svoje tradicije (grb i boja).</p> 
                <p>U razdoblju nakon Drugoga svjetskog rata bio je glavni predstavnik zagrebačkog nogometa te jedan od četiriju najuspješnijih klubova u SFRJ uz splitski Hajduk te beogradske klubove Crvena zvezda i Partizan koji su zbog dominacije u jugoslavenskom nogometu dobili naziv velika četvorka. Osvojio je jugoslavenska prvenstva 1947./48., 1953./54., 1957./58., 1981./82. i kupove 1951., 1959./60., 1962./63., 1964./65., 1968./69., 1979./80. i 1982./83.</p>
                <p>U sezoni 2018./19. Dinamo se uspio probiti do playoffa Europske lige. U grupnoj fazi ostao je neporažen s 14 bodova. Tako se plasirao u 1/16 finala gdje je u gostima izgubio od Viktorije Plzen rezultatom 2:1. Na Maksimiru, Dinamo je deklasirao ovaj češki klub rezultatom 3:0 i ušao u osminu finala protiv portugalske Benfice. Doma je Dinamo slavio s 1:0 uz mnogo propuštenih prilika, a izgubio u Lisabonu rezultatom 3:0. Dinamo je svojim povratkom u Europu osigurao nastup čak 5 hrvatskih klubova u europska natjecanja za sezonu 2019./20. i prekinuo pauzu dugu 21 godinu, od sezone 1997./98. kada je izgubio u osmini finala od snažnog Atlético Madrida (2:1). Zanimljivo je, ali i bizarno, da je ovo prvi playoff nekog hrvatskog nogometnog kluba u velikom europskom natjecanju u 21. stoljeću (pretposljednji put 1998.), unatoč velikim uspjesima reprezentacije (bronca i srebro na SP-ima) za to vrijeme. Nastavljajući uspjehe u europskim natjecanjima, Dinamo je 18. ožujka 2021. pobjedom nad Tottenhamom rezultatom 3:0 (3:2) ušao u povijesno četvrtfinale Europske lige 2020./21., što je najveći uspjeh tog kluba nakon točno 51 godine. Naime, Dinamo je svoje posljednje četvrtfinale nekog natjecanja pod EUFA-om posljednji puta igrao u Kupu pobjednika kupova 18. ožujka 1970. gdje je ispao od Schalke 04 ukupnim rezultatom 1:4. Zanimljivo je da je u grupnoj fazi Europske lige 2020./21. Dinamo bio 526 minuta bez primljenog pogotka što je rekord sa svih europskih klupskih natjecanja koje vodi UEFA. U ožujku 2024. godine održali su se prvi demokratski izbori za Skupštinu GNK Dinama, a glasanju je pristupilo 54,6 % članova. U prvoj izbornoj jedinici pobjedu je odnijela lista Dinamovo proljeće koju je predvodio Velimir Zajec.</p>
                <div class="slikaTekst"><img src="retro.jpg" alt=""></div>
            </div>
        </div>

        <hr>

        <div class="section">
            <div class="naslovSekcije">
                <h2>Dinamo u Europi</h2>
            </div>
            <div class="tekstClanak">
                <p>GNK Dinamo je odigrao najviše nogometnih utakmica u europskim nogometnim natjecanjima od svih hrvatskih klubova. Dinamo je prvi hrvatski klub koji je odigrao službenu utakmicu u europskom natjecanju. GNK Dinamo je do danas jedini hrvatski klub koji je osvojio neko europsko natjecanje, Kup velesajamskih gradova 1967. godine. Prva europska utakmica je odigrana 10. rujna 1958. protiv češke Dukle iz Praga i završila je neriješeno, rezultatom 2:2. Dinamo je najbolje rezultate postigao u šezdesetim godinama 20. stoljeća kad se natjecao u Kupu velesajamskih gradova. Dinamo je 1963. igrao finale tog natjecanja i izgubio od Valencije, a 1967. je uspio osvojiti natjecanje pobjedom u finalu nad Leeds Unitedom.</p> 
                <p>Kup velesajamskih gradova je priznat kao preteča Kupa UEFA ali nije bio organiziran od strane UEFA-e te ga UEFA ne smatra utakmice u Kupu velesajamskih gradova kao dio službene statistike klubova. FIFA naprotiv priznaje to natjecanje. Natjecanje se održavalo od 1955. godine do 1972. godine kada je ukinuto. Osim Dinama osvajači su bili tri puta Barcelona, po dva puta Valencia i Leeds United te po jednom Arsenal, Ferencváros, Newcastle United, Real Zaragoza i Roma. Dinamo je igrao i polufinale Kupa pobjednika kupova 1962. godine. Od sedamdesetih godina Dinamo ne postiže značajnije rezultate sve do druge polovice devedesetih kada se neovisnoj Hrvatskoj uspijeva dva puta kvalificirati u Ligu prvaka. U 21. stoljeću Dinamo je redovit sudionik europskih natjecanja, Lige prvaka i Europske lige. Dinamo je do sad ukupno sedam puta bio sudionik Lige prvaka u sezonama 1998./99., 1999./00., 2011./12., 2012./13., 2015./16., 2016./17., 2019./20. te je pet puta igrao skupinu Europske lige.</p>
                <p>Dinamo je nakon 49 godina prezimio u Europi što mu nije uspjelo od 1970. godine te je dočekao europsko proljeće 2019. kada je igrao osminu završnice Europske lige gdje je izgubio od Benfice (1:0, 0:3 prod.).Od 1958. godine do danas Dinamo je ukupno odigrao 313 europskih utakmica, a pobijedio je 124 puta uz 459 postignuta zgoditka.</p>
                <div class="slikaTekst"><img src="natjecanja.png" alt=""></div>
            </div>
        </div>  

        <hr>

        <div class="section">
            <div class="naslovSekcije">
                <h2>Stadion Maksimir</h2>
            </div>
            <div class="tekstClanak">
                <p>Stadion Maksimir najveći je nogometni stadion u Zagrebu na kojem domaće utakmice igra GNK Dinamo. Nazvan je po gradskom kvartu u kojem se nalazi. Prvotnim igralištem se služio HAŠK od 1912. godine, a 1948. godine na služenje ga je dobio Dinamo. Klub je uskoro na igralištu podigao zgradu, nasipe za stajanje, a na zapadnom dijelu malenu tribinu. Prvu utakmicu Dinamo je na Maksimiru odigrao 19. rujna 1948. godine s beogradskim Partizanom (2:1), pred 40.000 gledatelja.</p>
                <p>U ljeto 2011. godine stadion je podvrgnut temeljitom renoviranju. Sve su sjedalice zamijenjene, postavljen je novi teren s drenažom i grijanjem, te nove klupe za pričuvne igrače. Uređene su novinarske, VIP lože i mjesta za invalide, atletska je staza prekrivena plavom umjetnom travom, a zidovi ispod tribina plavim platnom. Stare stolice (5.000 stolica) donirane su u NK GOŠK Gabela. Tribina istok zatvorena je za gledatelje zbog potresa koji je pogodio Zagreb 22. ožujka 2020. godine, te je trenutačan kapacitet stadiona 24.851.</p>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2780.628249214195!2d16.01542107629337!3d45.818703071082055!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765d7c7c54294cd%3A0x141ee8b4a96f7e8e!2sStadion%20Maksimir!5e0!3m2!1shr!2shr!4v1716572366950!5m2!1shr!2shr" width="900" height="450" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>  

        <hr>


    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

    
<html>