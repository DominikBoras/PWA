<html>
<link rel="stylesheet" href="Style.css">  
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
         <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>
    <div class="bodyPage">
        <h2>Registracija</h2>
        <form action="registracija_submit.php" method="POST">
            <div class="unos">
                <label for="korisnicko_ime">Korisničko ime:</label>
                <input type="text" id="korisnicko_ime" name="korisnicko_ime" required>
            </div>
            <div class="unos">
                <label for="lozinka">Lozinka:</label>
                <input type="password" id="lozinka" name="lozinka" required>
            </div>
            <div class="unos">
                <label for="admin">Administrator:</label>
                <input type="checkbox" id="admin" name="admin" value="1">
            </div>
            <button type="submit">Registriraj se</button>
        </form>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>
</html>
