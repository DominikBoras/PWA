<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $naslov = $_POST['naslov'];
        $sazetak = $_POST['sazetak'];
        $tekst = $_POST['tekst'];
        $kategorija = $_POST['kategorija'];

        $sql_update = "UPDATE vijesti SET naslov=?, sazetak=?, tekst=?, kategorija=? WHERE id=?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ssssi", $naslov, $sazetak, $tekst, $kategorija, $id);
        $stmt_update->execute();
        $stmt_update->close();

        header("Location: administracija.php");
        exit();
    }

    $id = isset($_GET['id']) ? $_GET['id'] : 0;

    $sql_select = "SELECT naslov, sazetak, tekst, kategorija FROM vijesti WHERE id=?";
    $stmt = $conn->prepare($sql_select);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Uredi vijest</title>
        <link rel="stylesheet" href="Style.css">
    </head>
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>
        <div class="bodyPage">
            <h2>Uredi vijest</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <label for="naslov">Naslov vijesti:</label>
                <input type="text" id="naslov" name="naslov" value="<?php echo $row['naslov']; ?>" required><br><br>

                <label for="sazetak">Kratki sažetak vijesti:</label>
                <textarea id="sazetak" name="sazetak" rows="4" cols="50" required><?php echo $row['sazetak']; ?></textarea><br><br>

                <label for="tekst">Tekst vijesti:</label>
                <textarea id="tekst" name="tekst" rows="10" cols="50" required><?php echo $row['tekst']; ?></textarea><br><br>

                <label for="kategorija">Kategorija vijesti:</label>
                <select id="kategorija" name="kategorija" required>
                    <option value="Aktualno" <?php if($row['kategorija'] == 'Aktualno') echo 'selected'; ?>>Aktualno</option>
                    <option value="Informacije" <?php if($row['kategorija'] == 'Informacije') echo 'selected'; ?>>Informacije</option>
                </select><br><br>

                <button type="submit">Spremi promjene</button>
            </form>
        </div>

        <footer>
            <div class="footer">
                <p>Autor: Dominik Boras</p>
                <p>E-mail: dboras@tvz.hr</p>
                <p>2024.</p>
            </div>
        </footer>
</html>

<?php
    $conn->close();
?>
