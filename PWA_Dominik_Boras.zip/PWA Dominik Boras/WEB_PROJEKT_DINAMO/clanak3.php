<html>
        <link rel="stylesheet" href="style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datum"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="momcad.php">Momčad</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
            <h2>Aktualne vijesti</h2>
        </div>

        <div class="naslovClanka">
            <h4>TRENER JAKIROVIĆ I KAPETAN ADEMI: OVO JE JEDAN OD NAJSLAĐIH NASLOVA U POVIJESTI KLUBA</h4>
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika"><img src="clanak3.jpg"></div>
            <div class="sekcijaClanak">Aktualne vijesti</div>
            <div class="tekstClanak">
                <p>Trener i kapetan, strateg i produžena ruka na terenu, Sergej Jakirović i Arijan Ademi... Liderski dvojac maksimirske momčadi u slavljeničkom je ozračju izašao pred novinare nakon pobjede protiv Osijeka s 1:0 čime su plavi osigurali svoj 35. naslov prvaka u povijesti od čega 25. u HNL-u.</p>
                <p>- Čestitam momčadi, stručnom stožeru, svima u klubu, navijačima i svima koji vole Dinamo. Mislim da je ovo jedan od najslađih naslova u Dinamovoj povijesti, svi znamo što se događalo, teško je to sažeti u nekoliko rečenica. Od dana kad sam došao u klub prošli smo puno toga, puno uspona i padova, ali nikad nismo odustajali, kao što i naš slogan kaže - nema predaje. Uvijek sam vjerovao u ovu momčad i u sve što smo radili. Kad smo ispali iz Europe onda smo malo više radili jer prije praktički nismo ni mogli. Drago mi je zbog igrača, kad se samo sjetim svih razgovora, neprospavanih noći, analiza sa željom da budemo bolji... U ovakvoj sezoni osvojiti naslov dva kola prije kraja je fantastično - naglasio je trener Jakirović.</p>
                <p>U sličnom je tonu govorio i kapetan</p>
                <p>- Trener je sve rekao, trebalo je izaći iz svega ovoga kao pobjednik i ovo mi je možda i najslađi naslov. Konkurencija nam je bježala, imali smo i dvije utakmice manje, kad se sjetim kako se sve vrtjelo...</p>
                <p>A koji su im bili najteži trenuci u sezoni?</p>
                <p>- Ako ćemo gledati HNL, najteži trenutak je bio poraz u Velikoj Gorici. Imam dva teška poraza jer tu je i onaj na otvaranju proljeća protiv Lokomotive u Maksimiru. Izgledalo je kao da me netko čekićem u glavu udario, ništa mi nije bilo jasno. Ali znam dobro što sam rekao sutradan, da se nećemo predavati, da ćemo pokušati sve da odigramo dobro. Što se tiče Europe, znam da brojite samo poraze, to mi je čak i normalno jer naše društvo, nažalost, počiva na negativi, jer nitko ne spominje da smo i pobjeđivali. Prošli smo grupu, a i kad smo izgubili protiv Ballkanija znam što se događalo i što sam htio napraviti... Kad sam prespavao ipak nisam nikamo htio otići i rekao sam da ću se boriti do kraja. Možemo secirati Spartu i PAOK, ali ispali smo protiv ozbiljnih momčadi. U Europi nemate pravo na loš dan, sve se kažnjava. Od naša tri cilja dosad smo ostvarili dva, to su izboreno proljeće u Europi i osvojen naslov prvaka. Ostao nam je Kup - dodao je trener Jakirović na što se nadovezao maksimirski kapetan:</p>
                <p>- Najteže mi je bilo nakon poraza protiv Lokomotive. Osjećali smo se spremni, došli na utakmicu i dobili po glavi. Nevjerojatno. I sad kad me netko pita ne znam kako smo izgubili. Osjećali smo se spremni i dosta moćni i prije te utakmice i na pripremama, ali to što se dogodilo  u onih pet minuta u toj utakmici, teško je objasniti</p>
                <iframe width="80%" height="487" src="https://www.youtube.com/embed/c5roFE77mac" allowfullscreen></iframe>
                <p>Veliku su ulogu odigrali i navijači.</p>
                <p>- Pružali su nam veliku podršku bila je pozitiva, vjerovali smo i oni i mi da možemo izaći kao pobjednici -dodao je Dinamov strateg koji je obukao majicu s likom preminuloga navijača, Mislava Vučetića Kureta.</p>
                <p>- To je bio spontani potez, majicu mi je dao moj prijatelj, navijač. Vučetić je imao veliku ljubav prema Dinamu, to je najmanje što smo mogli napraviti. Zahvaljujem što su navijači cijelu sezonu bili uz nas, bodrili nas i kad nam nije išlo.</p>
                <p>Navijačima je, dakako, zahvalio i Dinamov kapetan:</p>
                <p>- Bilo bi nam teško bez njihove podrške, u najtežim su trenucima bili uz nas, pogurali nas do naslova. Hvala im na tome i pozivam ih da nas dođu podržati i u finalu Kupa.</p>
                <p>Neki su mediji, na sam dan utakmice protiv Osijeka, najavljivali rastanak Dinama i trenera Jakirovića.</p>
                <p>- Što se mene tiče, oguglao sam na to. Kad sam tek došao u klub neke su me stvari čudile pa sam malo išao u povijest i spoznao da je modus operandi isti kad si trener Dinama. I to bez obzira tko sjedi na trenerskoj klupi, uvijek je modus operandi isti - pojasnio je Dinamov strateg.</p>
                <p>Nakon osvojenoga naslova proključale su  emocije trenera Jakirovića, bile su vidljive i suze.</p>
                <p>- Jako mi puno znači ovaj naslov, proživio sam ga dosta emotivno, pogotovo s obzirom na sve što se događalo zadnjih dana. Znam da je moja obitelj maksimalno uz mene od prvog dana, znam što je sve prošla od mog dolaska u Dinamo, to nije baš normalno... Zahvaljujem joj na potpori i ljubavi koju mi daje i ovu pobjedu posvećujem njoj.</p>
            </div>            
        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>