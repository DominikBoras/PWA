<html>
        <link rel="stylesheet" href="style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datum"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="momcad.php">Momčad</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
            <h2>Informacije</h2>
        </div>

        <div class="naslovClanka">
            <h4>PETKOVIĆ ODIGRAO SVOJU 250. SLUŽBENU UTAKMICU ZA DINAMO</h4>
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika"><img src="clanak6.jpg"></div>
            <div class="sekcijaClanak">Informacije</div>
            <div class="tekstClanak">
                
                <p>Pogotkom u Sevilli isprovocirao je prolaz protiv Betisa, panenkom i silovitim udarcem s 11 metara potpisao je veliki preokret u završnici utakmice u Osijeku, još na samom otvaranju sezone asistirao Martinu Baturini za pokal pobjednika Superkupa, odigrao je i ključnu ulogu u jesenskoj maksimirskoj pobjedi protiv Rijeke, s dva gola u zadnjem kolu protiv Ballkanija povukao Dinamo u europsko proljeće u Konferencijskoj ligi, a nedavnom je delikatesom počastio plave navijače lansiravši momčad do dviju pobjeda na Poljudu u razmaku od samo pet dana, prvo pogotkom u prvenstvenoj utakmici, a potom i snažnim udarcem kojim je isprovocirao slavlje u Kupu kad je Sandro Kulenović odbijenu loptu zakucao u gol... I sad je maestralnim slobodnim udarcem režirao preokret na Rujevici u možda ključnoj utakmici u lovu na naslov prvaka. A sve je to tek djelić njegova opusa iz aktualne sezone u kojoj je mamio pljesak publike žonglerskim minijaturama, driblinzima, slalomima između braniča, dubinskim proigravanjima. Redatelj Dinamove igre, razigrani, raspoloženi i nadahnuti Bruno Petković ove je nedjelje protiv Rijeke na Rujevici odigrao svoju 250. službenu utakmicu u dresu maksimirskog kluba.</p>
                <p>A u tom je bogatom paketu bilo svakojakih delicija: geometrijski precizne „škarice“ kojima je uveo Dinamo u Ligu prvaka, asistencija petom za slavlje protiv češke Viktorije u onom famoznom europskom proljeću 2019. godine, „apotekarsko vaganje“ vratara čime bi s bijele točke poslao laganu loptu uz stajnu nogu, bajkoviti „no-look pasovi“ preko cijelog terena, piruete po uzoru na dvostruki aksl...</p>
                <p>U redu, zavukla se tu i poneka „nedaća“ poput neiskorištenog jedanaesterca protiv Hajduka u Maksimiru na otvaranju prvenstvene sezone, dva mjeseca izbivanja zbog ozljede...</p>
                <p>Kako god, od sredine kolovoza 2018. godine i njegove premijere u prvenstvenoj pobjedi protiv Osijeka s 2:1 u Zagrebu, Petković je s plavima osvojio devet trofeja: naslov prvaka u svakoj (!) od dosadašnjih pet punih sezona, jedan pokal pobjednika Kupa i tri Superkupa. To je tek djelić njegova dojmljiva maksimirskog opusa, a posebnu težinu imaju europske izvedbe. Čak četiri plasmana u proljetni dio kalendara europskih klupskih natjecanja, dva sudjelovanja u Ligi prvaka, drugo mjesto na povijesnoj klupskoj ljestvici najboljih strijelaca u Uefinim nadmetanjima... Na vrhu je Mislav Oršić s 28 pogodaka, a odmah iza njega je Petković s 26.</p>
                <p>Od tih 250 nastupa 159 ih je odigrao u HNL-u, 15 u hrvatskom Kupu, tri u Superkupu i 73 u europskim dvobojima. Pritom je ukupno postigao 82 pogotka uz 71 asistenciju, a uza sve to izborio 11 jedanaesteraca od kojih je devet pretvoreno u pogodak. Ujedno je i četvrti na ljestvici igrača s najviše europskih nastupa u Dinamovoj povijesti: na vrhu je Arijan Ademi sa 104, slijede Sammir sa 76, Dominik Livaković sa 74 i Petković sa 73.</p>
                <p>Dragi Bruno, od srca čestitke na velikih 250.</p>
            </div> 
            
        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>