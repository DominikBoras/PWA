<html>
        <link rel="stylesheet" href="style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datum"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="momcad.php">Momčad</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
            <h2>Aktualne vijesti</h2>
        </div>

        <div class="naslovClanka">
            <h4>KAPETAN ZVONIMIR BOBAN I SUIGRAČI U SPOMEN NA 13. SVIBNJA 1990.</h4>
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika"><img src="clanak2.jpg"></div>
            <div class="sekcijaClanak">Aktualne vijesti</div>
            <div class="tekstClanak">
                <p>Pljesak plavim akterima iz 1990. godine, druženje uz revijalnu utakmicu protiv momčadi navijača, humanitarna akcija uz donaciju dresova Zakladi „Nema predaje“.... Cijeli je ovaj program tek dio obilježavanja 34. godišnjice zbivanja uoči nikad odigrane utakmice Dinama i Crvene zvezde iz 13. svibnja 1990., zbivanja koja mnogi, zbog konteksta vremena i društvenih okolnosti, simbolički smatraju početkom borbe za hrvatsku samostalnost i neovisnost.</p>
                <p>Tog su dana, neposredno uoči početka utakmice, pripadnici organizirane navijačke skupine gostujućeg kluba, uz blagonaklonost tadašnje milicije, krenuli u rušilački pohod na južnoj tribini maksimirskog stadiona. Policija je to mirno promatrala, a pokazala mišiće samo prema Dinamovim navijačima koji nisu mirno željeli gledati uništavanje našeg stadiona. Ovakav pristran pristup tijela sigurnosti rezultirali su neredima koje i danas pamtimo kao otpor sustavu. Svojevrsna amblematska scena je reakcija Dinamova kapetana Zvonimira Bobana koji je, u želji da stane na kraj nepravdi i da obrani navijače, suigrače, rođake i sebe, nasrnuo na policajca uzvrativši mu udarac.</p>
                <p>Sama obljetnica se, dakle, poklapa s ovim ponedjeljkom, ali različitim smo je akcijama obilježili kroz cijeli vikend. Na maksimirski su travnjak, neposredno uoči subotnje prvenstvene utakmice protiv Osijeka, iskoračili predstavnici tadašnje Dinamove generacije igrača, bilo da su u momčadi bili u tom trenutku ili ranije u sezoni, i pritom ih je pozdravio aktualni predsjednik kluba, a tadašnji tehnički direktor, Velimir Zajec.</p>
                <p>Predvodio ih je kapetan Zvonimir Boban, a bili su tu i Mladen Mladenović, Muhamed Preljević, Kujtim Shala, Dražen Besek, Slavko Ištvanić, Vjekoslav Škrinjar, Dražen Boban, Fabijan Komljenović, Davor Matić i rezervni vratar Zdenko Miletić. Posebno smo se pritom zahvalili Shali, Preljeviću i Miletiću koji su samo za ovu priliku došli u Zagreb iz Njemačke.</p>
                <p>I dan kasnije, u nedjelju poslijepodne, gotovo je kompletna ova momčad uveličala i tradicionalni malonogometni turnir Bad Blue Boysa pod nazivom „Za sve one kojih nema“ na terenu s umjetnom travom na popularnom Klinčeku. Uoči finala turnira odigrali su revijalnu utakmicu protiv veteranske momčadi navijača i pritom zadivili, ne samo nogometnom vještinom, već i figurom i elegancijom kakva ih je krasila i u igračkim danima.</p>
                <p>I danas svojom staturom i crtama lica izgledaju kao da su iskočili iz postera iz igračkog doba. U revijalnom su dvoboju, u ugodnom koktelu zabave, nogometa, pjesme i skandiranja, pobijedili veteranski sastav navijača s 9:2. Kapetan Boban zabio je petom, Škrinjar gurao tunele, ali i suparnici su načinili poneku fintu, minijaturu ili piruetu koja bi katkad završila uspješno, a katkad iskakanjem iz ravnoteže i kotrljanjem po tlu... Trostruki je strijelac za pobjednike bio Škrinjar, po dva su gola dodali Komljenović i Shala, a po jednog kapetan Boban i gost iz kvartovske pionirske momčadi, dječak koji je osvanuo u majici s natpisom Modrić. Mrežu su s druge strane tresli Zoki i Tedy.</p>
                <p>Akteri su zaigrali u sadašnjoj Dinamovoj garnituri dresova pri čemu im je, dakako, na poleđini otisnuto prezime i broj u kojem su najčešće nastupali u igračkim danima. Nakon utakmice svi su se igrači potpisali na sve dresove koje ćemo potom pustiti u prodaju kao dio humanitarne akcije putem Zaklade “Nema predaje“.</p>
            </div>


        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>