    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sqlAktualno = "SELECT id, naslov, sazetak, tekst, kategorija, slika, datum FROM vijesti WHERE arhiva = 1 AND kategorija = 'Aktualno' ORDER BY datum DESC";
    $resultAktualno = $conn->query($sqlAktualno);

    $sqlInformacije = "SELECT id, naslov, sazetak, tekst, kategorija, slika, datum FROM vijesti WHERE arhiva = 1 AND kategorija = 'Informacije' ORDER BY datum DESC";
    $resultInformacije = $conn->query($sqlInformacije);

?>

<html>   
    <link rel="stylesheet" href="Style.css">
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>

        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>

    <div class="bodyPage">

        <hr>

        <div class="section">
            <div class="naslovSekcije">
                <h2>Aktualno</h2>
            </div>
            <div class="flex-container">
                <?php
                if ($resultAktualno->num_rows > 0) {
                    while($row = $resultAktualno->fetch_assoc()) {
                        echo '<div class="zoom"><article><a href="clanak.php?id=' . $row["id"] . '">';
                        echo '<img src="'.$row['slika'].'" class="articleSlika">';
                        echo '<h3>'.$row['naslov'].'</h3>';
                        echo '</a></article></div>';
                    }
                } else {
                    echo '<h2>"Nema vijesti za prikaz."</h2>';
                }
                ?>
                
            </div>
        </div>

        <hr>

        <div class="section">
            <div class="naslovSekcije">
                <h2>Informacije</h2>
            </div>
            <div class="flex-container">
                <?php
                if ($resultInformacije->num_rows > 0) {
                    while($row = $resultInformacije->fetch_assoc()) {
                        echo '<div class="zoom"><article><a href="clanak.php?id=' . $row["id"] . '">';
                        echo '<img src="'.$row['slika'].'" class="articleSlika">';
                        echo '<h3>'.$row['naslov'].'</h3>';
                        echo '</a></article></div>';
                    }
                } else {
                    echo '<h2>"Nema vijesti za prikaz."</h2>';
                }
                $conn->close();
                ?>
                


            </div>
            </div>

        <hr>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>
<html>