<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $delete_id = $_GET['id'];
        $sql_delete = "DELETE FROM vijesti WHERE id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $delete_id);
        $stmt_delete->execute();
        $stmt_delete->close();
    }

    header("Location: administracija.php");
    exit();
?>
