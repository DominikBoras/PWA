<html>
    <link rel="stylesheet" href="Style.css">
    
    <script>
        function validateForm(event) {
            event.preventDefault();
            var isValid = true;

            var elements = document.querySelectorAll('.error');
            elements.forEach(function(element) {
                element.textContent = '';
            });
            var inputs = document.querySelectorAll('.input');
            inputs.forEach(function(input) {
                input.style.borderColor = '';
            });

            var naslov = document.getElementById('naslov');
            if (naslov.value.length < 5 || naslov.value.length > 30) {
                isValid = false;
                naslov.style.borderColor = 'red';
                document.getElementById('naslovError').textContent = 'Naslov vijesti mora imati između 5 i 30 znakova.';
            }

            var sazetak = document.getElementById('sazetak');
            if (sazetak.value.length < 10 || sazetak.value.length > 100) {
                isValid = false;
                sazetak.style.borderColor = 'red';
                document.getElementById('sazetakError').textContent = 'Kratki sažetak vijesti mora imati između 10 i 100 znakova.';
            }

            var tekst = document.getElementById('tekst');
            if (tekst.value.trim() === '') {
                isValid = false;
                tekst.style.borderColor = 'red';
                document.getElementById('tekstError').textContent = 'Tekst vijesti ne smije biti prazan.';
            }

            var slika = document.getElementById('slika');
            if (slika.value === '') {
                isValid = false;
                slika.style.borderColor = 'red';
                document.getElementById('slikaError').textContent = 'Slika mora biti odabrana.';
            }

            var kategorija = document.getElementById('kategorija');
            if (kategorija.value === '') {
                isValid = false;
                kategorija.style.borderColor = 'red';
                document.getElementById('kategorijaError').textContent = 'Kategorija mora biti odabrana.';
            }

            var datum = document.getElementById('datum');
            if (kategorija.value === '') {
                isValid = false;
                datum.style.borderColor = 'red';
                document.getElementById('datumError').textContent = 'Datum mora biti odabran.';
            }

            if (isValid) {
                document.getElementById('newsForm').submit();
            }
        }
    </script>

    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>

        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>

    <div class="bodyPage">
        <h2>Unos vijesti</h2>
        <form id="newsForm" action="skripta.php" method="POST" enctype="multipart/form-data" onsubmit="validateForm(event)">
            <div class="unos">
                <label for="naslov">Naslov vijesti:</label>
                <input type="text" id="naslov" name="naslov">
                <div id="naslovError" class="error"></div>
            </div>

            <div class="unos">
                <label for="sazetak">Kratki sažetak vijesti:</label>
                <textarea id="sazetak" name="sazetak" rows="4" cols="50"></textarea>
                <div id="sazetakError" class="error"></div>
            </div>

            <div class="unos">
                <label for="tekst">Tekst vijesti:</label>
                <textarea id="tekst" name="tekst" rows="10" cols="50"></textarea>
                <div id="tekstError" class="error"></div>
            </div>

            <div class="unos">
                <label for="datum">Datum vijesti:</label>
                <input type="date" id="datum" name="datum">
                <div id="datumError" class="error"></div>
            </div>

            <div class="unos">
                <label for="kategorija">Kategorija vijesti:</label>
                <select id="kategorija" name="kategorija">
                    <option value="">Odaberite kategoriju</option>
                    <option value="Aktualno">Aktualno</option>
                    <option value="Informacije">Informacije</option>
                </select>
                <div id="kategorijaError" class="error"></div>
            </div>

            <div class="unos">
                <label for="slika">Odaberite sliku:</label>
                <input type="file" name="slika" id="slika" class="input">
                <div id="slikaError" class="error"></div>
            </div>

            <div class="unos">
                <label for="prikazi">Prikazati obavijest na stranici:</label>
                <input type="checkbox" id="prikazi" name="prikazi">
            </div>

            <button type="submit">Pošalji</button>
        </form>
    </div>


    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>
</html>