<link rel="stylesheet" href="Style.css">  
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $korisnicko_ime = $_POST['korisnicko_ime'];
        $lozinka = password_hash($_POST['lozinka'], PASSWORD_DEFAULT);
        $admin = isset($_POST['admin']) ? 1 : 0;

        $sql = "INSERT INTO korisnik (korisnicko_ime, lozinka, admin) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $korisnicko_ime, $lozinka, $admin);

        if ($stmt->execute()) {
            echo "<header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id='datumDanas'><?php echo date('d.m.Y'); ?></div>
            <nav>
                <ul>
                    <li><a href='index.php'>Početna</a></li>
                    <li><a href='o_nama.php'>O nama</a></li>
                    <li><a href='administracija.php'>Administracija</a></li>
                    <li><a href='unos.php'>Unos</a></li>
                    <li><a href='kategorija.php?kategorija=Aktualno'>Aktualno</a></li>
                    <li><a href='kategorija.php?kategorija=Informacije'>Informacije</a></li>
                </ul>
            </nav>
            </header>
            <div class='bodyPage'>
                <h4>Registracija uspješna. <a href='administracija.php' class='registracija'>Prijavite se</a></h4>
            </div>";
        } else {
            echo "<header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id='datumDanas'><?php echo date('d.m.Y'); ?></div>
            <nav>
                <ul>
                    <li><a href='index.php'>Početna</a></li>
                    <li><a href='o_nama.php'>O nama</a></li>
                    <li><a href='momcad.php'>Momčad</a></li>
                    <li><a href='administracija.php'>Administracija</a></li>
                    <li><a href='unos.php'>Unos</a></li>
                    <li><a href='kategorija.php?kategorija=Aktualno'>Aktualno</a></li>
                    <li><a href='kategorija.php?kategorija=Informacije'>Informacije</a></li>
                </ul>
            </nav>
            </header>
            <div class='bodyPage'>
                <h4>Došlo je do pogreške: </h4> . $stmt->error;
            </div>";
        }
    }

    $conn->close();

?>
