<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    if ($id > 0) {
        $sql = "SELECT naslov, sazetak, tekst, kategorija, slika, datum FROM vijesti WHERE id = ? AND arhiva = 1";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
        }
    }

    $conn->close();
?>

<html>
<head>
    <link rel="stylesheet" href="Style.css">
    <title><?php echo $row ? htmlspecialchars($row['naslov']) : 'Vijest nije pronađena'; ?></title>
</head>
<body>
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>

    <div class="bodyPage">
        <?php if ($row) { ?>
            <div class="naslovSekcijeClanak">
                <h2><?php echo htmlspecialchars($row['kategorija']); ?></h2>
            </div>
            <div class="naslovClanka">
                <h4><?php echo htmlspecialchars($row['naslov']); ?></h4>
            </div>
            <div id="datumClanak"><?php echo htmlspecialchars($row['datum']); ?></div>
            <div class="clanak">
                <div class="clanakSlika"><img src="<?php echo htmlspecialchars($row['slika']); ?>"></div>
                <div class="sekcijaClanak"><?php echo htmlspecialchars($row['kategorija']); ?></div>
                <div class="tekstClanak">
                    <p><?php echo nl2br(htmlspecialchars($row['tekst'])); ?></p>
                </div>
            </div>
        <?php } else { ?>
            <p>Vijest nije pronađena.</p>
        <?php } ?>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

</body>
</html>
