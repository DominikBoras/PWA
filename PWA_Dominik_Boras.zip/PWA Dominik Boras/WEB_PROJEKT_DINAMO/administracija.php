<html>  
    <link rel="stylesheet" href="Style.css">  
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>

        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>
</html>

<?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (!isset($_SESSION['korisnik'])) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $korisnicko_ime = $_POST['korisnicko_ime'];
            $lozinka = $_POST['lozinka'];
    
            $sql = "SELECT * FROM korisnik WHERE korisnicko_ime = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $korisnicko_ime);
            $stmt->execute();
            $result = $stmt->get_result();
    
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($lozinka, $user['lozinka'])) {
                    $_SESSION['korisnik'] = [
                        'korisnicko_ime' => $user['korisnicko_ime'],
                        'admin' => $user['admin']
                    ];
                } else {
                    echo "<h4>Pogrešno korisničko ime ili lozinka.</h4>";
                    exit();
                }
            } else {
                echo "<h4>Pogrešno korisničko ime ili lozinka.</h4>";
                exit();
            }
        } else {
            echo "<div class='bodyPage'>
                    <h4>Molimo prijavite se kako biste pristupili administracijskoj stranici.</h4>
                    <form action='administracija.php' method='POST'>
                    <div class='unos2'>
                        <label for='korisnicko_ime'>Korisničko ime:</label>
                        <input type='text' id='korisnicko_ime' name='korisnicko_ime' required>
                    </div>
                    <div class='unos2'>
                        <label for='lozinka'>Lozinka:</label>
                        <input type='password' id='lozinka' name='lozinka' required>
                    </div>
                    <button type='submit'>Prijava</button>
                  </form>
                    <h4>Nemate račun? <a href='registracija.php' class='registracija'>Registrirajte se ovdje</a></h4>
            </div>";
            exit();
        }
    }
    
    $korisnik = $_SESSION['korisnik'];
    $sql = "SELECT * FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $korisnik['korisnicko_ime']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (!$user['admin']) {
            echo "<h4>Pozdrav, " . htmlspecialchars($user['korisnicko_ime']) . ". Nemate pravo pristupa administracijskoj stranici.</h4>";
            exit();
        }
    } else {
        echo "Korisničko ime i/ili lozinka nisu ispravni.";
        exit();
    }
    
    if (isset($_GET['delete']) && !empty($_GET['delete'])) {
        $delete_id = $_GET['delete'];
        $sql_delete = "DELETE FROM vijesti WHERE id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $delete_id);
        $stmt_delete->execute();
        $stmt_delete->close();
    }
    
    $sql_select = "SELECT id, naslov, sazetak, tekst, kategorija, slika, datum FROM vijesti";
    $result = $conn->query($sql_select);
?>

<html>  
    <link rel="stylesheet" href="Style.css">
    <div class="bodyPage">
        <h2>Administracija vijesti</h2>
        <table class="admin">
            <tr>
                <th>Naslov</th>
                <th>Kategorija</th>
                <th>Datum</th>
                <th>Opcije</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["naslov"] . "</td>";
                    echo "<td>" . $row["kategorija"] . "</td>";
                    echo "<td>" . $row["datum"] . "</td>";
                    echo "<td><a href='uredi.php?id=" . $row["id"] . "'>Uredi</a> | <a href='izbrisi.php?id=" . $row["id"] . "'>Obriši</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Nema dostupnih vijesti.</td></tr>";
            }
            ?>
        </table>
        </div>

        <footer>
            <div class="footer">
                <p>Autor: Dominik Boras</p>
                <p>E-mail: dboras@tvz.hr</p>
                <p>2024.</p>
            </div>
        </footer>

    
</html>



<?php
    $conn->close();
?>
