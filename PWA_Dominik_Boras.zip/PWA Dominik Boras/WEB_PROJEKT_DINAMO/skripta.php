<html>

    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dinamo";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $naslov = $_POST['naslov'];
            $sazetak = $_POST['sazetak'];
            $tekst = $_POST['tekst'];
            $datum = $_POST['datum'];
            $kategorija = $_POST['kategorija'];
            $prikazi = isset($_POST['prikazi']) ? 1 : 0;

            $uploadFile = null;

            if (isset($_FILES['slika'])) {
                $slika = $_FILES['slika'];
                $slikaIme = basename($slika['name']);
                $slikaTmp = $slika['tmp_name'];
                $slikaVelicina = $slika['size'];
                $slikaTip = $slika['type'];
                $uploadFile = $slikaIme;
            }    
        }

        $stmt = $conn->prepare("INSERT INTO vijesti (naslov, sazetak, tekst, datum, kategorija, slika, arhiva) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssi", $naslov, $sazetak, $tekst, $datum, $kategorija, $uploadFile, $prikazi);

        if ($stmt->execute()) {
            echo "Vijest je uspješno pohranjena.";
        } else {
            echo "Greška: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    ?>

        <link rel="stylesheet" href="Style.css">    
        <header>
            <h1>GNK DINAMO ZAGREB</h1>
            <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>

            <nav>
                <ul>
                    <li><a href="index.php">Početna</a></li>
                    <li><a href="o_nama.php">O nama</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.php">Unos</a></li>
                    <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                    <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
                </ul>
            </nav>
        </header>

    <div class="bodyPage">
        <div class="naslovSekcijeClanak">
             <h2><?php echo $kategorija ?></h2> 
        </div>

        <div class="naslovClanka">
             <h4><?php echo $naslov ?></h4>  
        </div>

        <div id="datumClanak"><?php echo date("d.m.Y"); ?></div>

        <div class="clanak">
            <div class="clanakSlika">
                <img src="<?php echo $uploadFile ?>"> 
            </div> 
        

            <div class="sekcijaClanak"><?php echo $kategorija ?></div> 
            <div class="tekstClanak">
                <p><?php echo $tekst ?></p> 
            </div>


        </div>
    </div>

    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

<html>



</html>