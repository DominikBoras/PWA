<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dinamo";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $kategorija = isset($_GET['kategorija']) ? $_GET['kategorija'] : 'Aktualno';

    $sql = "SELECT id, naslov, sazetak, tekst, kategorija, slika, datum FROM vijesti WHERE kategorija = ? AND arhiva = 1 ORDER BY datum DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $kategorija);
    $stmt->execute();
    $result = $stmt->get_result();
?>

<html>
    <link rel="stylesheet" href="Style.css">    
    <header>
        <h1>GNK DINAMO ZAGREB</h1>
        <div id="datumDanas"><?php echo date("d.m.Y"); ?></div>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="o_nama.php">O nama</a></li>
                <li><a href="administracija.php">Administracija</a></li>
                <li><a href="unos.php">Unos</a></li>
                <li><a href="kategorija.php?kategorija=Aktualno">Aktualno</a></li>
                <li><a href="kategorija.php?kategorija=Informacije">Informacije</a></li>
            </ul>
        </nav>
    </header>

    <div class="bodyPage">
        <div class="section">
            <div class="naslovSekcije">
                <h2><?php echo htmlspecialchars($kategorija); ?></h2>
            </div>
            <div class="flex-container">
                <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo '<div class="zoom"><article><a href="clanak.php?id=' . $row["id"] . '">';
                            echo '<img src="'.$row['slika'].'" class="articleSlika">';
                            echo '<h3>'.$row['naslov'].'</h3>';
                            echo '</a></article></div>';
                        }
                    } else {
                        echo '<h2>"Nema vijesti za prikaz."</h2>';
                    }
                ?>  
            </div>
        </div>
        <hr>
    </div>


    <footer>
        <div class="footer">
            <p>Autor: Dominik Boras</p>
            <p>E-mail: dboras@tvz.hr</p>
            <p>2024.</p>
        </div>
    </footer>

</html>

<?php
    $stmt->close();
    $conn->close();
?>
